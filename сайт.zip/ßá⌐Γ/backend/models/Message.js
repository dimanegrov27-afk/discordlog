import mongoose from 'mongoose';

const messageSchema = new mongoose.Schema({
  discordMessageId: {
    type: String,
    required: true,
    unique: true
  },
  guildId: {
    type: String,
    required: true
  },
  channelId: {
    type: String,
    required: true
  },
  authorId: {
    type: String,
    required: true
  },
  authorName: {
    type: String,
    required: true
  },
  authorAvatar: String,
  content: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true
  }
});

messageSchema.index({ guildId: 1, channelId: 1, createdAt: -1 });
messageSchema.index({ authorName: 'text', content: 'text' });

export const Message = mongoose.model('Message', messageSchema);
