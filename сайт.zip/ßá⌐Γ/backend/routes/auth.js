import express from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { discordService } from '../services/discordService.js';

const router = express.Router();

router.post('/connect', async (req, res) => {
  const { token, guildId, channelId } = req.body;

  if (!token || !guildId || !channelId) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const result = await discordService.connectBot(token, guildId, channelId);

  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }

  const jwtToken = jwt.sign(
    { guildId, channelId },
    config.JWT_SECRET,
    { expiresIn: '24h' }
  );

  res.json({ token: jwtToken, message: result.message });
});

router.post('/disconnect', (req, res) => {
  const { guildId, channelId } = req.body;

  if (!guildId || !channelId) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const success = discordService.disconnectBot(guildId, channelId);

  if (success) {
    res.json({ message: 'Disconnected successfully' });
  } else {
    res.status(400).json({ error: 'Connection not found' });
  }
});

export default router;
