import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { discordService } from '../services/discordService.js';

const router = express.Router();

router.get('/all-logs', verifyToken, async (req, res) => {
  try {
    const { guildId } = req.user;
    const { search = '', author = '', limit = 50, skip = 0 } = req.query;

    const messages = discordService.getAllCategoryMessages(guildId, search, author);
    const total = messages.length;
    const paginated = messages.slice(parseInt(skip), parseInt(skip) + parseInt(limit));

    res.json({ messages: paginated, total });
  } catch (error) {
    console.error('Error fetching all logs:', error);
    res.status(500).json({ error: error.message });
  }
});

router.get('/:messageId', verifyToken, async (req, res) => {
  try {
    const { guildId } = req.user;
    const { messageId } = req.params;

    if (!messageId) {
      return res.status(400).json({ error: 'messageId is required' });
    }

    const message = discordService.getMessageById(guildId, messageId);
    
    if (!message) {
      return res.status(404).json({ error: 'Message not found' });
    }

    res.json({ message });
  } catch (error) {
    console.error('Error fetching message:', error);
    res.status(500).json({ error: error.message });
  }
});

router.get('/stats', verifyToken, async (req, res) => {
  try {
    const { guildId, channelId } = req.user;
    const stats = discordService.getStats(guildId, channelId);
    res.json({ stats });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: error.message });
  }
});

router.get('/category-channels', verifyToken, async (req, res) => {
  try {
    const { guildId, channelId } = req.user;
    const channels = await discordService.getChannelsInCategory(guildId, channelId);
    res.json({ channels });
  } catch (error) {
    console.error('Error fetching category channels:', error);
    res.status(500).json({ error: error.message });
  }
});

router.get('/', verifyToken, async (req, res) => {
  try {
    const { guildId } = req.user;
    const { channelId } = req.query;
    const { search = '', author = '', limit = 50, skip = 0 } = req.query;

    if (!channelId) {
      return res.status(400).json({ error: 'channelId is required' });
    }

    const messages = discordService.getMessages(guildId, channelId, search, author, false);
    const total = messages.length;
    const paginated = messages.slice(parseInt(skip), parseInt(skip) + parseInt(limit));

    res.json({ messages: paginated, total });
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ error: error.message });
  }
});

router.post('/copy', verifyToken, async (req, res) => {
  try {
    const { guildId, channelId } = req.user;
    const { sourceChannelId, messageText } = req.body;

    if (!sourceChannelId || !messageText) {
      return res.status(400).json({ error: 'sourceChannelId and messageText are required' });
    }

    // Копируем сообщение в текущий канал
    const result = await discordService.copyMessage(guildId, channelId, sourceChannelId, messageText);
    
    if (result.success) {
      res.json({ success: true, message: 'Message copied' });
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (error) {
    console.error('Error copying message:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;
