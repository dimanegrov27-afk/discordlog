import express from 'express';
import { webhookService } from '../services/webhookService.js';
import { verifyToken } from '../middleware/auth.js';

const router = express.Router();

router.post('/send', verifyToken, async (req, res) => {
  const { content, username, avatarUrl } = req.body;

  if (!content) {
    return res.status(400).json({ error: 'Content is required' });
  }

  const result = await webhookService.sendMessage(content, username, avatarUrl);

  if (result.success) {
    res.json({ message: 'Message sent successfully', messageId: result.messageId });
  } else {
    res.status(500).json({ error: result.error });
  }
});

router.post('/send-embed', verifyToken, async (req, res) => {
  const { embed, username } = req.body;

  if (!embed) {
    return res.status(400).json({ error: 'Embed is required' });
  }

  const result = await webhookService.sendEmbed(embed, username);

  if (result.success) {
    res.json({ message: 'Embed sent successfully', messageId: result.messageId });
  } else {
    res.status(500).json({ error: result.error });
  }
});

router.post('/stats', verifyToken, async (req, res) => {
  const { stats } = req.body;

  if (!stats || !Array.isArray(stats)) {
    return res.status(400).json({ error: 'Stats array is required' });
  }

  const result = await webhookService.sendMessageStats(stats);

  if (result.success) {
    res.json({ message: 'Stats sent successfully' });
  } else {
    res.status(500).json({ error: result.error });
  }
});

export default router;
