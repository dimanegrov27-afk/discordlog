import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import { config } from './config.js';
import authRoutes from './routes/auth.js';
import messageRoutes from './routes/messages.js';
import webhookRoutes from './routes/webhook.js';
import { discordService } from './services/discordService.js';

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

// Middleware
app.use(cors({ origin: config.FRONTEND_URL }));
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/webhook', webhookRoutes);

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// WebSocket handling
wss.on('connection', (ws) => {
  console.log('Client connected');
  let subscriptionKey = null;

  ws.on('message', (data) => {
    try {
      const { type, guildId, channelId } = JSON.parse(data);

      if (type === 'subscribe') {
        const key = `${guildId}-${channelId}`;
        discordService.subscribe(key, (msg) => {
          ws.send(JSON.stringify({
            type: 'newMessage',
            data: {
              id: msg.id,
              author: msg.author.username,
              avatar: msg.author.displayAvatarURL({ size: 64 }),
              content: msg.content,
              timestamp: msg.createdTimestamp
            }
          }));
        });
      } else if (type === 'subscribe-all-logs') {
        subscriptionKey = `${guildId}-all-logs`;
        discordService.subscribe(subscriptionKey, (msg) => {
          ws.send(JSON.stringify({
            type: 'newMessage',
            data: {
              id: msg.id,
              authorName: msg.author.globalName || msg.author.username,
              authorAvatar: msg.author.displayAvatarURL({ size: 64, dynamic: true }),
              content: msg.content,
              timestamp: msg.createdTimestamp
            }
          }));
        });
      } else if (type === 'subscribe-channels') {
        subscriptionKey = `${guildId}-channels`;
        discordService.subscribe(subscriptionKey, (event) => {
          ws.send(JSON.stringify({
            type: 'channelCreated',
            channel: {
              id: event.channel.id,
              name: event.channel.name
            }
          }));
        });
      }
    } catch (error) {
      console.error('WebSocket error:', error);
    }
  });

  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

// Database connection
mongoose.connect(config.MONGODB_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => {
    console.warn('MongoDB connection warning:', err.message);
    console.warn('App will work without database - messages won\'t be persisted');
  });

// Start server
server.listen(config.PORT, () => {
  console.log(`Server running on port ${config.PORT}`);
});
