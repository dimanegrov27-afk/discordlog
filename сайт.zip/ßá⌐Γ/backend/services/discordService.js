import { Client, GatewayIntentBits, ChannelType } from 'discord.js';
import fs from 'fs';
import path from 'path';

const CACHE_DIR = './cache';
const CACHE_FILE = path.join(CACHE_DIR, 'messages.json');

if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

class DiscordService {
  constructor() {
    this.clients = new Map();
    this.listeners = new Map();
    this.messages = new Map();
    this.channelIds = new Map(); // Сохраняем маппинг названий на ID
    this.loadCache();
  }

  loadCache() {
    try {
      if (fs.existsSync(CACHE_FILE)) {
        const data = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
        for (const [key, messages] of Object.entries(data)) {
          this.messages.set(key, messages);
        }
        console.log('✓ Кэш загружен');
      }
    } catch (error) {
      console.error('Error loading cache:', error);
    }
  }

  saveCache() {
    try {
      const data = {};
      for (const [key, messages] of this.messages.entries()) {
        data[key] = messages;
      }
      fs.writeFileSync(CACHE_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error('Error saving cache:', error);
    }
  }

  async connectBot(token, guildId, channelId) {
    const key = `${guildId}-${channelId}`;

    if (this.clients.has(key)) {
      return { success: true, message: 'Already connected' };
    }

    try {
      const client = new Client({
        intents: [
          GatewayIntentBits.Guilds,
          GatewayIntentBits.GuildMessages,
          GatewayIntentBits.MessageContent,
          GatewayIntentBits.DirectMessages
        ]
      });

      await client.login(token);

      const guild = await client.guilds.fetch(guildId).catch(() => null);
      if (!guild) {
        client.destroy();
        throw new Error('Guild not found or bot has no access');
      }

      const channel = await guild.channels.fetch(channelId).catch(() => null);
      if (!channel || channel.type !== ChannelType.GuildText) {
        client.destroy();
        throw new Error('Channel not found or is not a text channel');
      }

      const categoryId = channel.parentId;
      console.log(`Bot connected to guild ${guildId}, channel ${channelId}, category ${categoryId}`);

      const channels = await guild.channels.fetch();
      const targetChannels = channels.filter(ch => 
        ch.parentId === categoryId && 
        ch.type === ChannelType.GuildText && 
        (ch.name === 'only-kill' || ch.name === 'damage')
      );
      
      for (const ch of targetChannels.values()) {
        const chKey = `${guildId}-${ch.id}`;
        if (!this.messages.has(chKey)) {
          this.messages.set(chKey, []);
        }
        this.channelIds.set(`${guildId}-${ch.name}`, ch.id);
        
        if (this.messages.get(chKey).length === 0) {
          console.log(`Loading messages for ${ch.name}...`);
          await this.loadHistoricalMessages(ch, guildId, ch.id);
        } else {
          console.log(`✓ Using cached messages for ${ch.name} (${this.messages.get(chKey).length} messages)`);
        }
      }

      client.on('messageCreate', async (msg) => {
        if (msg.guildId === guildId) {
          await this.saveMessage(msg, guildId, msg.channelId);
          const msgKey = `${guildId}-${msg.channelId}`;
          this.notifyListeners(msgKey, msg);
          this.notifyListeners(`${guildId}-all-logs`, msg);
        }
      });

      client.on('messageUpdate', async (oldMsg, newMsg) => {
        if (newMsg.guildId === guildId) {
          await this.saveMessage(newMsg, guildId, newMsg.channelId);
          const msgKey = `${guildId}-${newMsg.channelId}`;
          this.notifyListeners(msgKey, newMsg);
          this.notifyListeners(`${guildId}-all-logs`, newMsg);
        }
      });

      client.on('channelCreate', async (newChannel) => {
        if (newChannel.guildId === guildId && newChannel.parentId === categoryId && newChannel.type === ChannelType.GuildText) {
          console.log(`New channel created in category: ${newChannel.name}`);
          const newChKey = `${guildId}-${newChannel.id}`;
          if (!this.messages.has(newChKey)) {
            this.messages.set(newChKey, []);
          }
          await this.loadHistoricalMessages(newChannel, guildId, newChannel.id);
          this.notifyListeners(`${guildId}-category-update`, { type: 'channelCreated', channel: newChannel });
        }
      });

      this.clients.set(key, { client, channel, guildId, channelId, categoryId });
      return { success: true, message: 'Connected successfully' };
    } catch (error) {
      console.error('Connection error:', error);
      return { success: false, error: error.message };
    }
  }

  async loadHistoricalMessages(channel, guildId, channelId) {
    try {
      let allMessages = [];
      let lastId = null;
      let totalLoaded = 0;
      const START_DATE = new Date('2026-02-09');
      
      while (true) {
        const options = { limit: 100 };
        if (lastId) options.before = lastId;
        
        const messages = await channel.messages.fetch(options);
        if (messages.size === 0) break;
        
        let hasOlderMessages = false;
        for (const msg of messages.values()) {
          const msgDate = new Date(msg.createdTimestamp);
          
          if (msgDate < START_DATE) {
            hasOlderMessages = true;
            break;
          }
          
          if (msg.author.bot) {
            await this.saveMessage(msg, guildId, channelId);
            totalLoaded++;
          }
        }
        
        if (hasOlderMessages) break;
        
        allMessages = allMessages.concat(Array.from(messages.values()));
        lastId = messages.last().id;
      }
      
      console.log(`✓ Loaded ${totalLoaded} messages from channel ${channel.name} (${channelId}) since 09.02.2026`);
    } catch (error) {
      if (error.code === 50001) {
        console.log(`✗ No access to channel ${channel.name} (${channelId})`);
      } else {
        console.error(`✗ Error loading ${channel.name}:`, error.message);
      }
    }
  }

  async saveMessage(msg, guildId, channelId) {
    try {
      if (!msg.author.bot) {
        return;
      }

      const key = `${guildId}-${channelId}`;
      const authorName = msg.author.globalName || msg.author.username || 'Unknown';
      const avatarUrl = msg.author.displayAvatarURL({ size: 64, dynamic: true });

      let content = msg.content || '';
      if (msg.embeds && msg.embeds.length > 0) {
        const embed = msg.embeds[0];
        if (embed.title) content += `\n${embed.title}`;
        if (embed.description) content += `\n${embed.description}`;
        if (embed.fields && embed.fields.length > 0) {
          for (const field of embed.fields) {
            content += `\n${field.name}: ${field.value}`;
          }
        }
      }

      const messageData = {
        _id: msg.id,
        id: msg.id,
        discordMessageId: msg.id,
        guildId,
        channelId,
        authorId: msg.author.id,
        authorName: authorName,
        authorAvatar: avatarUrl,
        content: content || '',
        timestamp: msg.createdTimestamp,
        createdAt: new Date(msg.createdTimestamp)
      };

      if (!this.messages.has(key)) {
        this.messages.set(key, []);
      }
      
      const messages = this.messages.get(key);
      if (!messages.find(m => m.id === msg.id)) {
        messages.unshift(messageData);
        if (messages.length > 5000) {
          messages.pop();
        }
        this.saveCache();
      }

      console.log(`Message saved: ${authorName} - ${content.substring(0, 50)}`);
    } catch (error) {
      console.error('Error saving message:', error);
    }
  }

  getAllCategoryMessages(guildId, search = '', author = '') {
    let messages = [];
    
    for (const [key, msgs] of this.messages.entries()) {
      if (key.startsWith(guildId)) {
        messages = messages.concat(msgs);
      }
    }

    messages.sort((a, b) => b.timestamp - a.timestamp);

    if (search) {
      const searchLower = search.toLowerCase();
      messages = messages.filter(m => {
        const content = m.content.toLowerCase();
        
        if (search.match(/^\d{17}$/)) {
          return content.includes(search);
        }
        
        if (content.includes(`Player: ${search}`) || content.includes(`Name: ${search}`)) {
          return true;
        }
        
        if (content.includes(`Victim:`) && content.includes(search)) {
          return true;
        }
        if (content.includes(`Killer:`) && content.includes(search)) {
          return true;
        }
        
        return content.includes(searchLower);
      });
    }

    if (author) {
      messages = messages.filter(m => 
        m.authorName.toLowerCase().includes(author.toLowerCase())
      );
    }

    return messages;
  }

  getMessageById(guildId, messageId) {
    // Ищем сообщение по ID во всех каналах гильдии
    for (const [key, messages] of this.messages.entries()) {
      if (key.startsWith(guildId)) {
        const message = messages.find(m => m.id === messageId || m._id === messageId);
        if (message) {
          return message;
        }
      }
    }
    return null;
  }

  getMessages(guildId, channelId, search = '', author = '', searchAllChannels = false) {
    let messages = [];
    let actualChannelId = channelId;

    if (channelId === 'only-kill' || channelId === 'damage') {
      actualChannelId = this.channelIds.get(`${guildId}-${channelId}`);
      if (!actualChannelId) {
        return [];
      }
    }

    const key = `${guildId}-${actualChannelId}`;
    messages = [...(this.messages.get(key) || [])];

    if (search) {
      const searchLower = search.toLowerCase();
      messages = messages.filter(m => {
        const content = m.content.toLowerCase();
        
        if (search.match(/^\d{17}$/)) {
          return content.includes(search);
        }
        
        if (content.includes(`Player: ${search}`) || content.includes(`Name: ${search}`)) {
          return true;
        }
        
        if (content.includes(`Victim:`) && content.includes(search)) {
          return true;
        }
        if (content.includes(`Killer:`) && content.includes(search)) {
          return true;
        }
        
        return content.includes(searchLower);
      });
    }

    if (author) {
      messages = messages.filter(m => 
        m.authorName.toLowerCase().includes(author.toLowerCase())
      );
    }

    messages.sort((a, b) => b.timestamp - a.timestamp);

    return messages;
  }

  getStats(guildId, channelId) {
    const key = `${guildId}-${channelId}`;
    const messages = this.messages.get(key) || [];
    
    const stats = {};
    messages.forEach(msg => {
      stats[msg.authorName] = (stats[msg.authorName] || 0) + 1;
    });

    return Object.entries(stats)
      .map(([name, count]) => ({ _id: name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }

  subscribe(key, callback) {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, []);
    }
    this.listeners.get(key).push(callback);
  }

  notifyListeners(key, msg) {
    const callbacks = this.listeners.get(key) || [];
    callbacks.forEach(cb => cb(msg));
  }

  async getChannelsInCategory(guildId, channelId) {
    const connection = Array.from(this.clients.values()).find(
      c => c.guildId === guildId && c.channelId === channelId
    );

    if (!connection) {
      return [];
    }

    try {
      const channel = connection.channel;
      const guild = channel.guild;
      const categoryId = channel.parentId;

      if (!categoryId) {
        return [];
      }

      const channels = await guild.channels.fetch();
      const categoryChannels = channels
        .filter(ch => ch.parentId === categoryId && ch.type === ChannelType.GuildText)
        .map(ch => ({
          id: ch.id,
          name: ch.name,
          type: 'text'
        }));

      for (const ch of categoryChannels) {
        const key = `${guildId}-${ch.id}`;
        if (!this.messages.has(key)) {
          const discordChannel = channels.get(ch.id);
          if (discordChannel) {
            await this.loadHistoricalMessages(discordChannel, guildId, ch.id);
          }
        }
      }

      return categoryChannels;
    } catch (error) {
      console.error('Error fetching category channels:', error);
      return [];
    }
  }

  async copyMessage(guildId, channelId, sourceChannelId, messageText) {
    try {
      const connection = Array.from(this.clients.values()).find(
        c => c.guildId === guildId
      );

      if (!connection) {
        return { success: false, error: 'Bot not connected' };
      }

      const guild = connection.client.guilds.cache.get(guildId);
      
      const sourceChannel = await guild.channels.fetch(sourceChannelId);
      if (!sourceChannel) {
        return { success: false, error: 'Source channel not found' };
      }

      const messages = await sourceChannel.messages.fetch({ limit: 10 });
      
      const targetChannel = await guild.channels.fetch(channelId);
      for (const msg of messages.reverse().values()) {
        if (msg.embeds && msg.embeds.length > 0) {
          await targetChannel.send({ embeds: msg.embeds });
        } else if (msg.content) {
          await targetChannel.send(msg.content);
        }
      }
      
      return { success: true, message: 'Messages copied successfully' };
    } catch (error) {
      console.error('Error copying message:', error);
      return { success: false, error: error.message };
    }
  }

  deleteMessage(guildId, channelId, messageId) {
    const key = `${guildId}-${channelId}`;
    const messages = this.messages.get(key) || [];
    
    const index = messages.findIndex(m => m.id === messageId || m._id === messageId);
    if (index !== -1) {
      messages.splice(index, 1);
      console.log(`Message deleted from channel ${channelId}`);
      return true;
    }
    return false;
  }

  disconnectBot(guildId, channelId) {
    const key = `${guildId}-${channelId}`;
    const connection = this.clients.get(key);

    if (connection) {
      connection.client.destroy();
      this.clients.delete(key);
      this.listeners.delete(key);
      return true;
    }
    return false;
  }
}

export const discordService = new DiscordService();
