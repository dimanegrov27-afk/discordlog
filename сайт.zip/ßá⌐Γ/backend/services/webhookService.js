import axios from 'axios';

const WEBHOOK_URL = 'https://discord.com/api/webhooks/1471535625504297102/X01yc5Eh5g4IrqgbfQE8wBLW4lym3Wj7oCpvGRwd2HvKsR1oKGjt6qAQ4r9yBx7cAPr6';

export const webhookService = {
  async sendMessage(content, username = 'Discord Tracker', avatarUrl = null) {
    try {
      const payload = {
        content,
        username,
        ...(avatarUrl && { avatar_url: avatarUrl })
      };

      const response = await axios.post(WEBHOOK_URL, payload);
      return { success: true, messageId: response.data.id };
    } catch (error) {
      console.error('Webhook error:', error.message);
      return { success: false, error: error.message };
    }
  },

  async sendEmbed(embed, username = 'Discord Tracker') {
    try {
      const payload = {
        username,
        embeds: [embed]
      };

      const response = await axios.post(WEBHOOK_URL, payload);
      return { success: true, messageId: response.data.id };
    } catch (error) {
      console.error('Webhook error:', error.message);
      return { success: false, error: error.message };
    }
  },

  async sendMessageStats(stats) {
    const embed = {
      title: '📊 Статистика сообщений',
      color: 0x7c3aed,
      fields: stats.slice(0, 10).map((stat, idx) => ({
        name: `${idx + 1}. ${stat._id}`,
        value: `${stat.count} сообщений`,
        inline: true
      })),
      timestamp: new Date().toISOString()
    };

    return this.sendEmbed(embed, 'Message Stats');
  },

  async notifyNewMessage(author, content, avatarUrl) {
    const embed = {
      title: `💬 Новое сообщение от ${author}`,
      description: content.substring(0, 2048),
      color: 0xec4899,
      thumbnail: { url: avatarUrl },
      timestamp: new Date().toISOString()
    };

    return this.sendEmbed(embed, 'New Message Alert');
  }
};
