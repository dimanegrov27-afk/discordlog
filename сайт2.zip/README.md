# Discord Message Tracker

Веб-приложение для отслеживания и анализа сообщений из Discord-канала в реальном времени.

## Функционал

- ✅ Подключение к Discord серверу через Bot Token
- ✅ Получение сообщений в реальном времени (WebSocket)
- ✅ Отображение аватара, имени, текста и времени сообщения
- ✅ Поиск по тексту сообщений
- ✅ Фильтрация по имени автора
- ✅ Хранение сообщений в MongoDB
- ✅ Статистика по авторам
- ✅ Защита токена (не хранится на клиенте)
- ✅ Обработка ошибок

## Требования

- Node.js 16+
- MongoDB (локально или облако)
- Discord Bot Token

## Установка

### 1. Клонирование и установка зависимостей

```bash
# Backend
cd backend
npm install

# Frontend (в отдельном терминале)
cd frontend
npm install
```

### 2. Настройка переменных окружения

Создайте файл `.env` в папке `backend`:

```bash
cp .env.example backend/.env
```

Отредактируйте `backend/.env`:

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/discord-tracker
JWT_SECRET=your-secret-key-change-in-production
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
```

### 3. Запуск MongoDB

```bash
# Если MongoDB установлена локально
mongod

# Или используйте MongoDB Atlas (облако)
# Обновите MONGODB_URI в .env
```

### 4. Создание Discord Bot

1. Перейдите на [Discord Developer Portal](https://discord.com/developers/applications)
2. Нажмите "New Application"
3. Перейдите в "Bot" → "Add Bot"
4. Скопируйте токен (это ваш Discord Bot Token)
5. Включите необходимые интенты:
   - Message Content Intent
   - Server Members Intent
6. Добавьте бота на сервер через OAuth2 URL с правами:
   - `read:messages/view channels`
   - `read message history`

### 5. Запуск приложения

```bash
# Backend (из папки backend)
npm run dev

# Frontend (из папки frontend, в новом терминале)
npm run dev
```

Приложение будет доступно по адресу: `http://localhost:5173`

## Использование

1. Откройте приложение в браузере
2. Введите:
   - Discord Bot Token
   - Guild ID (ID сервера)
   - Channel ID (ID канала)
3. Нажмите "Connect"
4. Сообщения начнут загружаться и обновляться в реальном времени

### Как получить IDs

1. Включите Developer Mode в Discord (User Settings → Advanced → Developer Mode)
2. Правый клик на сервер → Copy Server ID
3. Правый клик на канал → Copy Channel ID

## Архитектура

### Backend

- **Express.js** - REST API
- **discord.js** - Discord API клиент
- **MongoDB** - база данных
- **WebSocket** - реальное время
- **JWT** - аутентификация

### Frontend

- **React** - UI
- **Axios** - HTTP клиент
- **WebSocket** - подписка на новые сообщения
- **Vite** - сборщик

## API Endpoints

### Аутентификация

```
POST /api/auth/connect
Body: { token, guildId, channelId }
Response: { token, message }

POST /api/auth/disconnect
Body: { guildId, channelId }
```

### Сообщения

```
GET /api/messages?search=text&author=name&limit=50&skip=0
Headers: Authorization: Bearer <token>
Response: { messages, total }

GET /api/messages/stats
Headers: Authorization: Bearer <token>
Response: { stats }
```

## Безопасность

- ✅ Токен не хранится на клиенте
- ✅ JWT для аутентификации
- ✅ CORS настроен
- ✅ Валидация входных данных
- ✅ Обработка ошибок

## Структура БД

### Message Collection

```javascript
{
  discordMessageId: String,      // ID сообщения в Discord
  guildId: String,               // ID сервера
  channelId: String,             // ID канала
  authorId: String,              // ID автора
  authorName: String,            // Имя автора
  authorAvatar: String,          // URL аватара
  content: String,               // Текст сообщения
  timestamp: Date,               // Время отправки
  createdAt: Date                // Время сохранения
}
```

## Решение проблем

### "Guild not found"
- Проверьте, что бот добавлен на сервер
- Проверьте правильность Guild ID

### "Channel not found"
- Убедитесь, что это текстовый канал
- Проверьте правильность Channel ID
- Убедитесь, что бот имеет доступ к каналу

### MongoDB connection error
- Убедитесь, что MongoDB запущена
- Проверьте MONGODB_URI в .env

### WebSocket не подключается
- Убедитесь, что backend запущен на порту 5000
- Проверьте CORS настройки

## Лицензия

MIT
