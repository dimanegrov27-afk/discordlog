import React, { useState, useEffect } from 'react';
import LoginForm from './components/LoginForm';
import SearchBar from './components/SearchBar';
import MessageList from './components/MessageList';
import ChannelList from './components/ChannelList';
import PlayerFilter from './components/PlayerFilter';
import './styles/App.css';

export default function App() {
  const [connected, setConnected] = useState(false);
  const [guildId, setGuildId] = useState('');
  const [channelId, setChannelId] = useState('');
  const [searchParams, setSearchParams] = useState({ search: '', author: '' });
  const [allMessages, setAllMessages] = useState([]);
  const [selectedPlayer, setSelectedPlayer] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const savedGuildId = localStorage.getItem('guildId');
    const savedChannelId = localStorage.getItem('channelId');
    const isLoggedIn = localStorage.getItem('isLoggedIn');

    if (token && savedGuildId && savedChannelId && isLoggedIn) {
      setConnected(true);
      setGuildId(savedGuildId);
      setChannelId(savedChannelId);
    }
  }, []);

  const handleConnect = ({ guildId, channelId }) => {
    setGuildId(guildId);
    setChannelId(channelId);
    setConnected(true);
  };

  const handleChannelSelect = (newChannelId) => {
    setChannelId(newChannelId);
    localStorage.setItem('channelId', newChannelId);
  };

  const handlePlayerSelect = (playerName) => {
    setSelectedPlayer(playerName);
    setSearchParams({ search: playerName, author: '' });
  };

  const handleAvatarClick = () => {
    // Показываем все логи из обоих каналов
    setSelectedPlayer(null);
    setSearchParams({ search: '', author: '' });
  };

  const handleDisconnect = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('guildId');
    localStorage.removeItem('channelId');
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    setConnected(false);
    setGuildId('');
    setChannelId('');
  };

  return (
    <div className="app">
      {!connected ? (
        <LoginForm onConnect={handleConnect} />
      ) : (
        <div className="main-container">
          <header className="header">
            <h1 onClick={handleAvatarClick} style={{ cursor: 'pointer' }}>EOD ЛОГИ</h1>
            <button onClick={handleDisconnect} className="disconnect-btn">
              Отключиться
            </button>
          </header>

          <SearchBar onSearch={setSearchParams} />
          <div className="content-grid">
            <div className="main-content">
              <MessageList
                searchParams={searchParams}
                guildId={guildId}
                channelId={channelId}
                onMessagesUpdate={setAllMessages}
              />
            </div>
            <div className="sidebar">
              <ChannelList 
                onChannelSelect={handleChannelSelect}
                guildId={guildId}
                channelId={channelId}
              />
              {!selectedPlayer && <PlayerFilter messages={allMessages} channelId={channelId} onPlayerSelect={handlePlayerSelect} />}
              {selectedPlayer && (
                <div style={{
                  background: 'linear-gradient(135deg, rgba(13, 17, 23, 0.8), rgba(26, 31, 46, 0.8))',
                  border: '2px solid #a8ff60',
                  borderRadius: '0',
                  padding: '20px',
                  marginTop: '20px',
                  boxShadow: '0 0 20px rgba(168, 255, 96, 0.15), inset 0 0 15px rgba(0, 0, 0, 0.5)',
                  position: 'relative'
                }}>
                  <div style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: 'repeating-linear-gradient(0deg, rgba(168, 255, 96, 0.02), rgba(168, 255, 96, 0.02) 1px, transparent 1px, transparent 2px)',
                    pointerEvents: 'none'
                  }}></div>
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                    position: 'relative',
                    zIndex: 1
                  }}>
                    <div style={{
                      fontSize: '14px',
                      fontWeight: '700',
                      color: '#a8ff60',
                      textShadow: '0 0 5px rgba(168, 255, 96, 0.5)',
                      fontFamily: "'Poppins', sans-serif",
                      wordBreak: 'break-word'
                    }}>
                      {selectedPlayer}
                    </div>
                    <button
                      onClick={() => setSelectedPlayer(null)}
                      style={{
                        padding: '8px 12px',
                        background: 'linear-gradient(135deg, rgba(168, 255, 96, 0.2), rgba(168, 255, 96, 0.1))',
                        border: '2px solid #a8ff60',
                        color: '#a8ff60',
                        borderRadius: '0',
                        cursor: 'pointer',
                        fontWeight: '600',
                        fontSize: '12px',
                        fontFamily: "'Poppins', sans-serif",
                        transition: 'all 0.3s',
                        width: '100%'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.background = 'linear-gradient(135deg, rgba(168, 255, 96, 0.4), rgba(168, 255, 96, 0.2))';
                        e.target.style.boxShadow = '0 0 15px rgba(168, 255, 96, 0.4)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.background = 'linear-gradient(135deg, rgba(168, 255, 96, 0.2), rgba(168, 255, 96, 0.1))';
                        e.target.style.boxShadow = 'none';
                      }}
                    >
                      ← Назад
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
