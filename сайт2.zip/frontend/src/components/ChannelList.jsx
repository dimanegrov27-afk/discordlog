import React, { useState, useEffect } from 'react';

export default function ChannelList({ onChannelSelect, guildId, channelId }) {
  // Жестко заданные каналы для отслеживания
  const channels = [
    { id: 'only-kill', name: 'only-kill', type: 'text' },
    { id: 'damage', name: 'damage', type: 'text' }
  ];

  return (
    <div className="channel-list">
      <h3>Логи</h3>
      <div className="channels">
        {channels.map((channel) => (
          <div 
            key={channel.id} 
            className={`channel-item ${channelId === channel.id ? 'active' : ''}`}
            onClick={() => onChannelSelect(channel.id)}
          >
            <span className="channel-name">#{channel.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
