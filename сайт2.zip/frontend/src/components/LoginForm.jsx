import React, { useState } from 'react';
import { authAPI } from '../services/api';

export default function LoginForm({ onConnect }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [token] = useState('MTQ3MjMyNjIwNDM3NDc4MjAyMw.GaIRWo.KR0KraKzaAx8Uf6kfJiZwoTVJ3LDX8CttzDOXg');
  const [guildId] = useState('1156102363975778334');
  const [channelId] = useState('1468534133260292252');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const ADMIN_USER = 'admin44';
  const ADMIN_PASS = '484833';

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    if (username === ADMIN_USER && password === ADMIN_PASS) {
      setLoading(true);
      try {
        const response = await authAPI.connect(token, guildId, channelId);
        localStorage.setItem('username', username);
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('guildId', guildId);
        localStorage.setItem('channelId', channelId);
        localStorage.setItem('discordToken', token);
        onConnect({ guildId, channelId });
      } catch (err) {
        setError(err.response?.data?.error || 'Connection failed');
      } finally {
        setLoading(false);
      }
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>☢ ВХОД В СИСТЕМУ</h1>
        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label>Имя пользователя</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Введите имя пользователя"
              required
            />
          </div>

          <div className="form-group">
            <label>Пароль</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Введите пароль"
              required
            />
          </div>

          {error && <div className="error-message">{error}</div>}

          <button type="submit" disabled={loading}>
            {loading ? 'Вход...' : 'Войти'}
          </button>
        </form>
      </div>
    </div>
  );
}
