import React, { useState, useEffect } from 'react';
import { messagesAPI } from '../services/api';

const LogIcon = ({ type }) => {
  const colors = {
    KILL: '#ff4757',
    HIT: '#ffa502',
    DMG: '#ff6348',
    LOG: '#a8ff60'
  };

  const icons = {
    KILL: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L15.09 8.26H22L17.45 12.5L19.54 18.76L12 14.26L4.46 18.76L6.55 12.5L2 8.26H8.91L12 2Z" fill={colors[type]} opacity="0.9"/>
        <path d="M12 2L15.09 8.26H22L17.45 12.5L19.54 18.76L12 14.26L4.46 18.76L6.55 12.5L2 8.26H8.91L12 2Z" stroke={colors[type]} strokeWidth="0.5" opacity="0.5"/>
      </svg>
    ),
    HIT: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="8" stroke={colors[type]} strokeWidth="2" opacity="0.9"/>
        <circle cx="12" cy="12" r="5" stroke={colors[type]} strokeWidth="1.5" opacity="0.6"/>
        <circle cx="12" cy="12" r="2" fill={colors[type]} opacity="0.8"/>
        <line x1="12" y1="4" x2="12" y2="2" stroke={colors[type]} strokeWidth="1.5" opacity="0.7"/>
        <line x1="12" y1="22" x2="12" y2="20" stroke={colors[type]} strokeWidth="1.5" opacity="0.7"/>
        <line x1="4" y1="12" x2="2" y2="12" stroke={colors[type]} strokeWidth="1.5" opacity="0.7"/>
        <line x1="22" y1="12" x2="20" y2="12" stroke={colors[type]} strokeWidth="1.5" opacity="0.7"/>
      </svg>
    ),
    DMG: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M13 2L16 8H22L18 12L20 18L13 14L6 18L8 12L4 8H10L13 2Z" fill={colors[type]} opacity="0.7"/>
        <path d="M13 2L16 8H22L18 12L20 18L13 14L6 18L8 12L4 8H10L13 2Z" stroke={colors[type]} strokeWidth="1" opacity="0.9"/>
      </svg>
    ),
    LOG: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" stroke={colors[type]} strokeWidth="1.5" opacity="0.8"/>
        <line x1="3" y1="8" x2="21" y2="8" stroke={colors[type]} strokeWidth="1" opacity="0.6"/>
        <line x1="6" y1="12" x2="18" y2="12" stroke={colors[type]} strokeWidth="0.8" opacity="0.5"/>
        <line x1="6" y1="15" x2="18" y2="15" stroke={colors[type]} strokeWidth="0.8" opacity="0.5"/>
        <line x1="6" y1="18" x2="14" y2="18" stroke={colors[type]} strokeWidth="0.8" opacity="0.5"/>
      </svg>
    )
  };
  return icons[type] || icons.LOG;
};

const parseLogData = (content) => {
  const lines = content.split('\n');
  const data = {};

  lines.forEach(line => {
    const trimmed = line.trim();
    if (trimmed.includes('Victim:')) data.victim = trimmed.split('Victim:')[1]?.trim();
    if (trimmed.includes('Killer:')) data.killer = trimmed.split('Killer:')[1]?.trim();
    if (trimmed.includes('Source:')) data.source = trimmed.split('Source:')[1]?.trim();
    if (trimmed.includes('ID:') && !data.victimId) data.victimId = trimmed.split('ID:')[1]?.trim();
    if (trimmed.includes('ID:') && data.victimId) data.killerId = trimmed.split('ID:')[1]?.trim();
    if (trimmed.includes('Position:')) data.position = trimmed.split('Position:')[1]?.trim();
    if (trimmed.includes('HP:')) data.hp = trimmed.split('HP:')[1]?.trim();
    if (trimmed.includes('Damage Dealt:')) data.damage = trimmed.split('Damage Dealt:')[1]?.split('Damage Type')[0]?.trim();
    if (trimmed.includes('Damage Type:')) data.damageType = trimmed.split('Damage Type:')[1]?.trim();
  });

  return data;
};

const LogCard = ({ msg, channelId, info }) => {
  const data = parseLogData(msg.content);
  const isKillLog = channelId === 'only-kill';

  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(13, 17, 23, 0.9), rgba(26, 31, 46, 0.9))',
      border: `2px solid ${isKillLog ? 'rgba(255, 71, 87, 0.4)' : 'rgba(255, 99, 72, 0.4)'}`,
      borderRadius: '8px',
      padding: '16px',
      marginBottom: '12px',
      boxShadow: `0 0 15px ${isKillLog ? 'rgba(255, 71, 87, 0.1)' : 'rgba(255, 99, 72, 0.1)'}`,
      transition: 'all 0.3s'
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '12px',
        paddingBottom: '12px',
        borderBottom: `1px solid ${isKillLog ? 'rgba(255, 71, 87, 0.2)' : 'rgba(255, 99, 72, 0.2)'}`
      }}>
        <span style={{
          fontSize: '13px',
          fontWeight: '700',
          color: isKillLog ? '#ff4757' : '#ff6348',
          display: 'flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <LogIcon type={isKillLog ? 'KILL' : 'DMG'} />
          {info.type}
        </span>
        <span style={{ fontSize: '11px', color: '#666' }}>
          {new Date(msg.timestamp || msg.createdAt).toLocaleString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
        {data.victim && (
          <div>
            <div style={{ fontSize: '11px', color: '#888', marginBottom: '4px', fontWeight: '600' }}>ЖЕРТВА</div>
            <div style={{ fontSize: '13px', color: '#d0d0d0', fontWeight: '500' }}>{data.victim}</div>
            {data.victimId && (
              <a href={`https://steamcommunity.com/profiles/${data.victimId.replace(/[\[\]()]/g, '')}`} target="_blank" rel="noopener noreferrer" style={{
                fontSize: '11px',
                color: '#ffa502',
                textDecoration: 'underline',
                cursor: 'pointer',
                display: 'block',
                marginTop: '4px'
              }}>
                {data.victimId.replace(/[\[\]()]/g, '')}
              </a>
            )}
          </div>
        )}

        {(data.killer || data.source) && (
          <div>
            <div style={{ fontSize: '11px', color: '#888', marginBottom: '4px', fontWeight: '600' }}>УБИЙЦА/ИСТОЧНИК</div>
            <div style={{ fontSize: '13px', color: '#d0d0d0', fontWeight: '500' }}>{data.killer || data.source}</div>
            {data.killerId && (
              <a href={`https://steamcommunity.com/profiles/${data.killerId.replace(/[\[\]()]/g, '')}`} target="_blank" rel="noopener noreferrer" style={{
                fontSize: '11px',
                color: '#ffa502',
                textDecoration: 'underline',
                cursor: 'pointer',
                display: 'block',
                marginTop: '4px'
              }}>
                {data.killerId.replace(/[\[\]()]/g, '')}
              </a>
            )}
          </div>
        )}
      </div>

      {data.damage && (
        <div style={{
          background: 'rgba(255, 99, 72, 0.1)',
          border: '1px solid rgba(255, 99, 72, 0.2)',
          borderRadius: '6px',
          padding: '8px 12px',
          marginBottom: '12px'
        }}>
          <div style={{ fontSize: '11px', color: '#888', marginBottom: '4px', fontWeight: '600' }}>УРОН</div>
          <div style={{ fontSize: '14px', color: '#ff6348', fontWeight: '700' }}>{data.damage}</div>
          {data.damageType && <div style={{ fontSize: '11px', color: '#999', marginTop: '4px' }}>{data.damageType}</div>}
        </div>
      )}

      {data.hp && (
        <div style={{
          background: 'rgba(168, 255, 96, 0.1)',
          border: '1px solid rgba(168, 255, 96, 0.2)',
          borderRadius: '6px',
          padding: '8px 12px',
          marginBottom: '12px'
        }}>
          <div style={{ fontSize: '11px', color: '#888', marginBottom: '4px', fontWeight: '600' }}>HP ПОСЛЕ ХИТА</div>
          <div style={{ fontSize: '14px', color: '#a8ff60', fontWeight: '700' }}>{data.hp}</div>
        </div>
      )}

      {data.position && (
        <div style={{ fontSize: '11px', color: '#666', padding: '8px', background: 'rgba(100, 100, 100, 0.1)', borderRadius: '4px' }}>
          Позиция: {data.position}
        </div>
      )}
    </div>
  );
};

export default function MessageList({ searchParams, guildId, channelId, onMessagesUpdate }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [skip, setSkip] = useState(0);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const limit = 50;

  useEffect(() => {
    setSkip(0);
    loadMessages();
  }, [searchParams, channelId]);

  const loadMessages = async () => {
    setLoading(true);
    try {
      const response = await messagesAPI.getMessages(
        searchParams.search,
        searchParams.author,
        limit,
        skip,
        channelId,
        false
      );
      setMessages(response.data.messages);
      setTotal(response.data.total);
      if (onMessagesUpdate) {
        onMessagesUpdate(response.data.messages);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMessages();
  }, [skip]);

  useEffect(() => {
    if (!autoRefresh) return;

    const ws = new WebSocket('ws://localhost:5000');

    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        guildId,
        channelId
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'newMessage') {
        setMessages(prev => {
          const updated = [data.data, ...prev];
          if (onMessagesUpdate) {
            onMessagesUpdate(updated);
          }
          return updated;
        });
        setTotal(prev => prev + 1);
      }
    };

    return () => ws.close();
  }, [guildId, channelId, autoRefresh, onMessagesUpdate]);

  const extractInfo = (content, channelId) => {
    const lines = content.split('\n');
    let type = 'LOG';

    for (const line of lines) {
      if (line.includes('Kill Report') || line.includes('Kill / Death Report')) type = 'KILL';
      else if (line.includes('Hit Report')) type = 'HIT';
      else if (line.includes('Damage')) type = 'DMG';
    }

    if (channelId === 'only-kill') {
      return { type: 'KILL/DEAD LOG', displayType: type };
    }
    if (channelId === 'damage' && type === 'DMG') {
      return { type: 'DAMAGE LOG', displayType: type };
    }

    return { type, displayType: type };
  };

  return (
    <div className="message-list">
      <div style={{ 
        padding: '20px', 
        borderBottom: '2px solid rgba(168, 255, 96, 0.3)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '12px',
        background: 'linear-gradient(90deg, rgba(168, 255, 96, 0.05), transparent)'
      }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center',
            gap: '8px',
            padding: '8px 12px',
            background: 'rgba(168, 255, 96, 0.1)',
            borderRadius: '6px',
            border: '1px solid rgba(168, 255, 96, 0.2)'
          }}>
            <span style={{ color: '#a8ff60', fontSize: '14px', fontWeight: '700' }}>
              {total}
            </span>
            <span style={{ color: '#888', fontSize: '12px' }}>
              логов
            </span>
          </div>
          <span style={{ color: '#666', fontSize: '12px', fontWeight: '500' }}>
            {Math.ceil(total / limit)} стр.
          </span>
        </div>
        <label style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '8px',
          cursor: 'pointer',
          color: '#d0d0d0',
          fontSize: '13px',
          padding: '6px 12px',
          background: autoRefresh ? 'rgba(168, 255, 96, 0.15)' : 'rgba(100, 100, 100, 0.1)',
          borderRadius: '6px',
          border: `1px solid ${autoRefresh ? 'rgba(168, 255, 96, 0.3)' : 'rgba(100, 100, 100, 0.2)'}`,
          transition: 'all 0.3s'
        }}>
          <input 
            type="checkbox" 
            checked={autoRefresh}
            onChange={(e) => setAutoRefresh(e.target.checked)}
            style={{ cursor: 'pointer', width: '16px', height: '16px', accentColor: '#a8ff60' }}
          />
          <span style={{ fontWeight: '500' }}>Live</span>
        </label>
      </div>

      {loading && messages.length === 0 && (
        <div className="loading" style={{ padding: '60px 20px', textAlign: 'center' }}>
          <div style={{ 
            display: 'inline-block',
            width: '40px',
            height: '40px',
            border: '3px solid rgba(168, 255, 96, 0.2)',
            borderTop: '3px solid #a8ff60',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            marginBottom: '16px'
          }}></div>
          <div style={{ color: '#a8ff60', fontSize: '14px', fontWeight: '600' }}>Загрузка логов...</div>
        </div>
      )}

      {messages.length === 0 && !loading && (
        <div className="empty-state" style={{ 
          padding: '60px 20px', 
          textAlign: 'center',
          color: '#666'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '12px', opacity: 0.5 }}>∅</div>
          <div style={{ fontSize: '14px', fontWeight: '500' }}>Логи не найдены</div>
        </div>
      )}

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>

      <div className="messages" style={{ padding: '20px' }}>
        {messages.map((msg, idx) => {
          const info = extractInfo(msg.content, channelId);
          if (!msg.content || msg.content.trim() === '') {
            return null;
          }
          return (
            <div key={msg._id || msg.id} style={{ animation: `slideIn 0.3s ease-out ${idx * 0.05}s both` }}>
              <style>{`
                @keyframes slideIn {
                  from {
                    opacity: 0;
                    transform: translateX(-10px);
                  }
                  to {
                    opacity: 1;
                    transform: translateX(0);
                  }
                }
              `}</style>
              <LogCard msg={msg} channelId={channelId} info={info} />
            </div>
          );
        })}
      </div>

      {total > limit && (
        <div className="pagination" style={{
          background: 'linear-gradient(90deg, rgba(168, 255, 96, 0.05), transparent)',
          borderTop: '2px solid rgba(168, 255, 96, 0.2)',
          padding: '20px'
        }}>
          <button
            onClick={() => setSkip(Math.max(0, skip - limit))}
            disabled={skip === 0}
            style={{ 
              opacity: skip === 0 ? 0.4 : 1,
              fontWeight: '600',
              fontSize: '13px'
            }}
          >
            Назад
          </button>
          <span style={{ 
            color: '#a8ff60', 
            fontWeight: '700',
            fontSize: '13px',
            padding: '0 16px',
            whiteSpace: 'nowrap'
          }}>
            {skip / limit + 1} / {Math.ceil(total / limit)}
          </span>
          <button
            onClick={() => setSkip(skip + limit)}
            disabled={skip + limit >= total}
            style={{ 
              opacity: skip + limit >= total ? 0.4 : 1,
              fontWeight: '600',
              fontSize: '13px'
            }}
          >
            Далее
          </button>
        </div>
      )}
    </div>
  );
}
