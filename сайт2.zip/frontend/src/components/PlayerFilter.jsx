import React, { useState, useEffect } from 'react';

const parseLogData = (content) => {
  const lines = content.split('\n');
  const data = {};

  lines.forEach(line => {
    const trimmed = line.trim();
    if (trimmed.includes('Victim:')) data.victim = trimmed.split('Victim:')[1]?.trim();
    if (trimmed.includes('Killer:')) data.killer = trimmed.split('Killer:')[1]?.trim();
    if (trimmed.includes('Source:')) data.source = trimmed.split('Source:')[1]?.trim();
  });

  return data;
};

export default function PlayerFilter({ messages, channelId, onPlayerSelect }) {
  const [victims, setVictims] = useState([]);
  const [killers, setKillers] = useState([]);

  useEffect(() => {
    const victimsMap = new Map();
    const killersMap = new Map();

    messages.forEach(msg => {
      const data = parseLogData(msg.content);
      
      if (data.victim && !data.victim.includes('NH_') && !data.victim.includes('KOD')) {
        victimsMap.set(data.victim, (victimsMap.get(data.victim) || 0) + 1);
      }
      
      if (channelId === 'only-kill' && data.killer && !data.killer.includes('NH_') && !data.killer.includes('KOD')) {
        killersMap.set(data.killer, (killersMap.get(data.killer) || 0) + 1);
      } else if (channelId === 'damage' && data.source && !data.source.includes('NH_') && !data.source.includes('KOD')) {
        killersMap.set(data.source, (killersMap.get(data.source) || 0) + 1);
      }
    });

    const sortedVictims = Array.from(victimsMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name]) => name);

    const sortedKillers = Array.from(killersMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name]) => name);

    setVictims(sortedVictims);
    setKillers(sortedKillers);
  }, [messages, channelId]);

  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(13, 17, 23, 0.8), rgba(26, 31, 46, 0.8))',
      border: '2px solid #a8ff60',
      borderRadius: '0',
      padding: '20px',
      marginTop: '20px',
      boxShadow: '0 0 20px rgba(168, 255, 96, 0.15), inset 0 0 15px rgba(0, 0, 0, 0.5)',
      position: 'relative'
    }}>
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'repeating-linear-gradient(0deg, rgba(168, 255, 96, 0.02), rgba(168, 255, 96, 0.02) 1px, transparent 1px, transparent 2px)',
        pointerEvents: 'none'
      }}></div>

      <h3 style={{
        color: '#a8ff60',
        fontSize: '16px',
        marginBottom: '16px',
        fontWeight: '700',
        letterSpacing: '0px',
        textShadow: '0 0 5px rgba(168, 255, 96, 0.5)',
        fontFamily: "'Poppins', sans-serif"
      }}>
        Последняя активность
      </h3>

      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '12px',
        overflow: 'hidden'
      }}>
        {/* Жертвы */}
        <div style={{ minWidth: 0 }}>
          <div style={{
            fontSize: '12px',
            color: '#888',
            marginBottom: '12px',
            fontWeight: '600',
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}>
            Жертвы
          </div>
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '8px'
          }}>
            {victims.length > 0 ? (
              victims.map((victim, idx) => (
                <div
                  key={idx}
                  onClick={() => onPlayerSelect(victim)}
                  style={{
                    padding: '8px 10px',
                    background: 'rgba(255, 71, 87, 0.1)',
                    border: '1px solid rgba(255, 71, 87, 0.3)',
                    borderRadius: '4px',
                    color: '#ff4757',
                    fontSize: '12px',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    minWidth: 0
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.background = 'rgba(255, 71, 87, 0.2)';
                    e.target.style.borderColor = '#ff4757';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.background = 'rgba(255, 71, 87, 0.1)';
                    e.target.style.borderColor = 'rgba(255, 71, 87, 0.3)';
                  }}
                >
                  {victim}
                </div>
              ))
            ) : (
              <div style={{ color: '#666', fontSize: '12px' }}>Нет данных</div>
            )}
          </div>
        </div>

        {/* Убийцы/Источники */}
        <div style={{ minWidth: 0 }}>
          <div style={{
            fontSize: '12px',
            color: '#888',
            marginBottom: '12px',
            fontWeight: '600',
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}>
            {channelId === 'only-kill' ? 'Убийцы' : 'Источники'}
          </div>
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '8px'
          }}>
            {killers.length > 0 ? (
              killers.map((killer, idx) => (
                <div
                  key={idx}
                  onClick={() => onPlayerSelect(killer)}
                  style={{
                    padding: '8px 10px',
                    background: 'rgba(255, 99, 72, 0.1)',
                    border: '1px solid rgba(255, 99, 72, 0.3)',
                    borderRadius: '4px',
                    color: '#ff6348',
                    fontSize: '12px',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    minWidth: 0
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.background = 'rgba(255, 99, 72, 0.2)';
                    e.target.style.borderColor = '#ff6348';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.background = 'rgba(255, 99, 72, 0.1)';
                    e.target.style.borderColor = 'rgba(255, 99, 72, 0.3)';
                  }}
                >
                  {killer}
                </div>
              ))
            ) : (
              <div style={{ color: '#666', fontSize: '12px' }}>Нет данных</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
