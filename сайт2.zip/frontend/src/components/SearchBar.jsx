import React, { useState, useEffect } from 'react';

const SearchIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="6" cy="6" r="4" stroke="#666" strokeWidth="1.5"/>
    <line x1="9" y1="9" x2="14" y2="14" stroke="#666" strokeWidth="1.5"/>
  </svg>
);

const UserIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="8" cy="5" r="3" stroke="#666" strokeWidth="1.5"/>
    <path d="M2 14C2 11.2 4.7 9 8 9C11.3 9 14 11.2 14 14" stroke="#666" strokeWidth="1.5"/>
  </svg>
);

export default function SearchBar({ onSearch }) {
  const [search, setSearch] = useState('');
  const [author, setAuthor] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch({ search, author });
    }, 300);

    return () => clearTimeout(timer);
  }, [search, author, onSearch]);

  return (
    <div className="search-bar">
      <div style={{ position: 'relative', flex: 1 }}>
        <input
          type="text"
          placeholder="Поиск по Steam ID, имени игрока..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
          style={{ paddingLeft: '32px' }}
        />
        <span style={{ 
          position: 'absolute', 
          left: '10px', 
          top: '50%', 
          transform: 'translateY(-50%)',
          display: 'flex',
          alignItems: 'center'
        }}>
          <SearchIcon />
        </span>
      </div>
      <div style={{ position: 'relative', flex: 1 }}>
        <input
          type="text"
          placeholder="Фильтр по боту..."
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          className="search-input"
          style={{ paddingLeft: '32px' }}
        />
        <span style={{ 
          position: 'absolute', 
          left: '10px', 
          top: '50%', 
          transform: 'translateY(-50%)',
          display: 'flex',
          alignItems: 'center'
        }}>
          <UserIcon />
        </span>
      </div>
    </div>
  );
}
