import React, { useState, useEffect } from 'react';
import { messagesAPI } from '../services/api';
import api from '../services/api';

export default function StatsPanel() {
  const [stats, setStats] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    setError('');
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('Not authenticated');
        setLoading(false);
        return;
      }

      const response = await messagesAPI.getStats();
      setStats(response.data.stats || []);
    } catch (err) {
      console.error('Stats error:', err);
      setError('Failed to load stats');
    } finally {
      setLoading(false);
    }
  };

  const sendStatsToWebhook = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Not authenticated');
        return;
      }

      await api.post('/webhook/stats', { stats });
      alert('Stats sent to webhook!');
    } catch (err) {
      console.error('Send stats error:', err);
      alert('Failed to send stats: ' + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div className="stats-panel">
      <div className="stats-header">
        <h3>Top Authors</h3>
        <button onClick={sendStatsToWebhook} className="send-stats-btn">
          Send to Webhook
        </button>
      </div>

      {loading && <div className="loading">Loading stats...</div>}
      {error && <div className="error-message">{error}</div>}

      <div className="stats-list">
        {stats.map((stat, idx) => (
          <div key={idx} className="stat-item">
            <span className="rank">#{idx + 1}</span>
            <span className="name">{stat._id}</span>
            <span className="count">{stat.count} messages</span>
          </div>
        ))}
      </div>
    </div>
  );
}
