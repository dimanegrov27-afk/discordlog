import React from 'react';

export default function UserModal({ user, onClose }) {
  if (!user) return null;

  const discordProfileUrl = `discord://users/${user.authorId}`;

  const handleOpenDiscord = () => {
    window.location.href = discordProfileUrl;
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>
        
        <div className="modal-header">
          <img src={user.authorAvatar} alt={user.authorName} className="modal-avatar" />
        </div>

        <div className="modal-body">
          <h2>{user.authorName}</h2>
          <p className="user-id">ID: {user.authorId}</p>
          
          <div className="modal-stats">
            <div className="stat">
              <span className="label">Messages</span>
              <span className="value">{user.messageCount || 1}</span>
            </div>
          </div>

          <button 
            onClick={handleOpenDiscord}
            className="discord-link"
          >
            Open in Discord →
          </button>
        </div>
      </div>
    </div>
  );
}
