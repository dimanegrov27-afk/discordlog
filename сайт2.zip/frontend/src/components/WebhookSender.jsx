import React, { useState } from 'react';
import api from '../services/api';

export default function WebhookSender() {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleSend = async (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('Not authenticated');
        return;
      }

      await api.post('/webhook/send', {
        content: message.trim(),
        username: 'Discord Tracker Bot'
      });
      setSuccess('Message sent to webhook!');
      setMessage('');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Webhook error:', err);
      setError(err.response?.data?.error || err.message || 'Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="webhook-sender">
      <h3>Send to Webhook</h3>
      <form onSubmit={handleSend}>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Enter message to send to webhook..."
          rows="3"
        />
        <button type="submit" disabled={loading || !message.trim()}>
          {loading ? 'Sending...' : 'Send'}
        </button>
      </form>
      {success && <div className="success-message">{success}</div>}
      {error && <div className="error-message">{error}</div>}
    </div>
  );
}
