import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authAPI = {
  connect: (token, guildId, channelId) =>
    api.post('/auth/connect', { token, guildId, channelId }),
  disconnect: (guildId, channelId) =>
    api.post('/auth/disconnect', { guildId, channelId })
};

export const messagesAPI = {
  getMessages: (search = '', author = '', limit = 50, skip = 0, channelId = '', searchAll = false) =>
    api.get('/messages', { params: { search, author, limit, skip, channelId, searchAll } }),
  getAllLogs: (search = '', author = '', limit = 50, skip = 0) =>
    api.get('/messages/all-logs', { params: { search, author, limit, skip } }),
  getStats: () =>
    api.get('/messages/stats'),
  deleteMessage: (messageId, channelId) =>
    api.delete(`/messages/${messageId}`, { params: { channelId } }),
  getCategoryChannels: () =>
    api.get('/messages/category-channels'),
  copyMessages: (channelId, sourceChannelId) =>
    api.post('/messages/copy', { sourceChannelId, messageText: '' })
};

export default api;
